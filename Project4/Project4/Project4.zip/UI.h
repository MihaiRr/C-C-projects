#ifndef UI_HEADER_FILE
#define UI_HEADER_FILE

#include "Services.h"

void GetInput(Map *map);

#endif